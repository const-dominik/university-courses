const incr = require("./zad3_a.js");
const x = incr(5);
console.log(x);