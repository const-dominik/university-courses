const increment = x => x + 1;
module.exports = increment;