const incr = (n: number) => ++n;
export const a = 5;
export default incr;
