import increment, { a } from "./zad4";

console.log(increment(a));