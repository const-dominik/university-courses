const incr = (num: number): number => ++num;
const decr = (num: number): number => --num;

const val = 94;
console.log(incr(val));
console.log(decr(val));
