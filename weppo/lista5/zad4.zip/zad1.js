var incr = function (num) { return ++num; };
var decr = function (num) { return --num; };
var val = 4;
console.log(incr(val));
val++;
console.log(decr(val));
